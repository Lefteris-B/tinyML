//Numpy array shape [8]
//Min -0.007490663789
//Max 0.030153175816
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[8];
#else
model_default_t b2[8] = {-0.0074906638, -0.0051554921, 0.0301531758, -0.0025341015, 0.0047472171, 0.0023487473, -0.0005067647, 0.0278048217};
#endif

#endif
