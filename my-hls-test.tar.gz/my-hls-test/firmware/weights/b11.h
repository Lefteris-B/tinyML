//Numpy array shape [10]
//Min -0.031032593921
//Max 0.052022788674
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[10];
#else
model_default_t b11[10] = {-0.0214013308, 0.0520227887, -0.0115499049, -0.0310325939, -0.0305774491, -0.0143367955, -0.0023689119, 0.0261707157, 0.0107970405, 0.0041807438};
#endif

#endif
